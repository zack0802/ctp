% *******************************************************************************
%                                                                               
%                    <��Ʊ,�ڻ�,������,������,�˹����ܷ����ר��>	                
%                            �Ϻ����ǽ����Ϣ�������޹�˾		                    
%                          ��˾��ַ:www.gaiafintech.com
%                                ΢�ź�:suade1984                               
%                              ����:suade1984@163.com  
%                         ���ļ�����ֱ�Ӳ����ڻ�CTP���׽ӿ�
%                                                                              
% *******************************************************************************

gaia = GaiaCTPMT();%����LordCTP MATLAB����
loginStatus = 1;%gaia.loginGaia('15921975627', '111111'); %��¼��LordCTP
if loginStatus >= 0
    ctpID = gaia.create();%����CTPʵ��
    if ctpID > 0
        reqID = gaia.generateReqID(ctpID); %��������id
        if reqID >= 0
            gaia.start(ctpID, reqID, '218.202.237.33:10012', '218.202.237.33:10002', '9999', '021739', '123456');%��¼����,���׷�����
            while (1 == 1)
                if gaia.isMdLogined(ctpID) >= 0
                    if gaia.isTdLogined(ctpID) >= 0
                        fprintf('��¼�ɹ�!!!!!!!!!!\n');
                        break;
                    end
                end
                fprintf('��¼���ɹ�, 5S���������\n');
                pause(5);
            end
            subStatus = gaia.subMarketDatas(ctpID, reqID, 'IF1812');%���Ĺ�Ʊ��Ϣ
            orderStatus = 0;
            if subStatus > 0
                while (1 == 1) %ѭ����ȡ��Ʊ��Ϣ
                    mp = gaia.getDepthMarketData(ctpID);
                    %keys(mp);
                    %values(mp);
                    keys = mp.keys;
                    len = length(keys) - 1;
                    if len > 0 %����й�Ʊ��Ϣ�������Ʊ��Ϣ
                        %fprintf('MarketDats->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n')
                        for w = 1: len
                           fprintf('%s : %s \n', char(keys(w)), char(mp(char(keys(w)))));
                        end
                        orderStatus = orderStatus + 1;
                    else
                         fprintf('û������\n');
                    end
                    if orderStatus == 1
                        if len > 30
                            price = char(mp(char(keys(29))));
                            status = gaia.bidOpen(ctpID, reqID, 'IF1812', price, '1', '3', 'afasfa');
                            orderStatus = orderStatus + 1;
                            %fprintf('bidOpenOrder, CU1812, %s\n', price);
                        end
                    end
                    trademp = gaia.getTradeRecord(ctpID);
                    tradekeys = trademp.keys;
                    len = length(tradekeys) - 1;
                    if len > 0 
                        fprintf('trade->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:\n');
                        for y = 1: len + 1
                            %fprintf('%d : %s \n', y, char(trademp(char(tradekeys(y)))));
                            fprintf('%s : %s \n', char(tradekeys(y)), char(trademp(char(tradekeys(y)))));
                        end
                    end
                    pause(5);
                    if orderStatus >= 2
                        ordermp = gaia.getOrderInfo(ctpID);
                        orderkeys = ordermp.keys;
                        len = length(orderkeys) - 1;
                        if len > 0 
                        fprintf('order->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:\n');
                            for z = 1: len
                                fprintf('%s : %s \n', char(orderkeys(z)), char(ordermp(char(orderkeys(z)))));
                            end
                        end
                    end
                end
            end
            fprintf('����ʧ��!!\n');
        end
    end
end
 fprintf('��¼ʧ��!!\n');