% *******************************************************************************
%                                                                              
%                    <��Ʊ,�ڻ�,������,������,�˹����ܷ����ר��>	                
%                            �Ϻ����ǽ����Ϣ�������޹�˾		                
%                          ��˾��ַ:www.gaiafintech.com                        
%                                ΢�ź�:suade1984                               
%                              ����:suade1984@163.com  
%                             ���ļ�����matlabͬC++�ĶԽ�
%                                                                              
% *******************************************************************************

classdef GaiaCTPMT
    %GaiaMTM GaiaMT Matlab �ӿ�
    %   ��ʱû����ϸ˵��
    
    properties
    end
    
    methods
        function ctp = GaiaCTPMT()
            mex GaiaCTPMTMAT.cpp
        end
    end
    
    methods
        function[status] = askClose(self, ctpID, requestID, code, price, qty, timeCondition, orderRef)
            status = str2num(GaiaCTPMTMAT(1, ctpID, requestID, code, price, qty, timeCondition, orderRef));
        end
        
        function[status] = askCloseToday(self, ctpID, requestID, code, price, qty, timeCondition, orderRef)
            status = str2num(GaiaCTPMTMAT(2, ctpID, requestID, code, price, qty, timeCondition, orderRef));
        end
        
        function[status] = askOpen(self, ctpID, requestID, code, price, qty, timeCondition, orderRef)
            status = str2num(GaiaCTPMTMAT(3, ctpID, requestID, code, price, qty, timeCondition, orderRef));
        end
        
        function[status] = bidClose(self, ctpID, requestID, code, price, qty, timeCondition, orderRef)
            status = str2num(GaiaCTPMTMAT(4, ctpID, requestID, code, price, qty, timeCondition, orderRef));
        end
        
        function[status] = bidCloseToday(self, ctpID, requestID, code, price, qty, timeCondition, orderRef)
            status = str2num(GaiaCTPMTMAT(5, ctpID, requestID, code, price, qty, timeCondition, orderRef));
        end
        
        function[status] = bidOpen(self, ctpID, requestID, code, price, qty, timeCondition, orderRef)
            status = str2num(GaiaCTPMTMAT(6, ctpID, requestID, code, price, qty, timeCondition, orderRef));
        end
        
        function[status] = canceGaiaer(self, ctpID, requestID, exchangeID, orderSysID, orderRef)
            status = str2num(GaiaCTPMTMAT(7, ctpID, requestID, exchangeID, orderSysID, orderRef));
        end
        
        function[ctpid] = create(self)
            ctpid = str2num(GaiaCTPMTMAT(8));
        end
        
        function[reqID] = generateReqID(self, ctpid)
            reqID = str2num(GaiaCTPMTMAT(9, ctpid));
        end
        
        function[result] = getAccountData(self, ctpID)
            strRet = GaiaCTPMTMAT(10, ctpID);
            if strmd == 'E'
                result = java.util.Hashtable;
                result.put(1, 0);
                return;
            end			
			titleStr = 'BrokerID,AccountID,PreMortgage,PreCredit,PreDeposit,PreBalance,PreMargin,InterestBase,Interest,Deposit,Withdraw,FrozenMargin,FrozenCash,FrozenCommission,CurrMargin,CashIn,Commission,CloseProfit,PositionProfit,Balance,Available,WithdrawQuota,Reserve,TradingDay,SettlementID,Credit,Mortgage,ExchangeMargin,DeliveryMargin,ExchangeDeliveryMargin,ReserveBalance,CurrencyID,PreFundMortgageIn,PreFundMortgageOut,FundMortgageIn,FundMortgageOut,FundMortgageAvailable,MortgageableFund,SpecProductMargin,SpecProductFrozenMargin,SpecProductCommission,SpecProductFrozenCommission,SpecProductPositionProfit,SpecProductCloseProfit,SpecProductPositionProfitByAlg,SpecProductExchangeMargin';
            titArr = regexp(titleStr, ',' ,'split');
            dataArr = regexp(strmd, ',', 'split');
            retput = containers.Map();
            dataArrSize = length(dataArr);
            for i = 1:dataArrSize
                retput(char(titArr{i})) = char(dataArr{i});
            end
            result = retput;
        end
        
        function[result] = getBrokerID(self, ctpID)
            result = GaiaCTPMTMAT(11, ctpID);
        end
        function[result] = getCommissionRate(self, ctpID, code)
            strRet = GaiaCTPMTMAT(12, ctpID, code);
			if strmd == 'E'
                result = java.util.Hashtable;
                result.put(1, 0);
                return;
            end			
			titleStr = 'InstrumentID,InvestorRange,BrokerID,m_investorID,OpenRatioByMoney,OpenRatioByVolume,CloseRatioByMoney,CloseRatioByVolume,CloseTodayRatioByMoney,CloseTodayRatioByVolume';
            titArr = regexp(titleStr, ',' ,'split');
            dataArr = regexp(strmd, ',', 'split');
            retput = containers.Map();
            dataArrSize = length(dataArr);
            for i = 1:dataArrSize
                retput(char(titArr{i})) = char(dataArr{i});
            end
            result = retput;
        end
		
        function[result] = getDepthMarketData(self, ctpid)
            strmd = GaiaCTPMTMAT(13, ctpid);
            if strmd == 'E'
                result = java.util.Hashtable;
                result.put(1, 0);
                return;
            end
            titleStr = 'TradingDay,InstrumentID,ExchangeID,ExchangeInstID,LastPrice,PreSettlementPrice,PreClosePrice,PreOpenInterest,OpenPrice,HighestPrice,LowestPrice,Volume,Turnover,OpenInterest,ClosePrice,SettlementPrice,UpperLimitPrice,LowerLimitPrice,PreDelta,CurrDelta,UpdateTime,UpdateMillisec,BidPrice1,BidVolume1,AskPrice1,AskVolume1,BidPrice2,BidVolume2,AskPrice2,AskVolume2,BidPrice3,BidVolume3,AskPrice3,AskVolume3,BidPrice4,BidVolume4,AskPrice4,AskVolume4,BidPrice5,BidVolume5,AskPrice5,AskVolume5,AveragePrice,ActionDay';
            titArr = regexp(titleStr, ',' ,'split');
            dataArr = regexp(strmd, ',', 'split');
            retput = containers.Map();
            dataArrSize = length(dataArr);
            for i = 1:dataArrSize
                retput(char(titArr{i})) = char(dataArr{i});
            end
            result = retput;
        end
        
        function[result] = getInstrumentsData(self, ctpID)
            strmd = GaiaCTPMTMAT(14, ctpID);
            if strmd == 'E'
                result = java.util.Hashtable;
                result.put(1, 0);
                return;
            end
            titleStr = 'InstrumentID,ExchangeID,InstrumentName,ExchangeInstID,ProductID,ProductClass,DeliveryYear,DeliveryMonth,MaxMarketOrderVolume,MinMarketOrderVolume,MaxLimitOrderVolume,MinLimitOrderVolume,VolumeMultiple,PriceTick,CreateDate, OpenDate,ExpireDate,StartDelivDate,EndDelivDate,InstLifePhase,IsTrading,PositionType,PositionDateType,LongMarginRatio,ShortMarginRatio,MaxMarginSideAlgorithm,UnderlyingInstrID,StrikePrice,OptionsType,UnderlyingMultiple,CombinationType';
            titArr = regexp(titleStr, ',' ,'split');
            dataArr = regexp(strmd, ',', 'split');
            retput = containers.Map();
            dataArrSize = length(dataArr);
            for i = 1:dataArrSize
                retput(char(titArr{i})) = char(dataArr{i});
            end
            result = retput;
        end
        
        function[result] = getInvestorID(self, ctpID)
            GaiaCTPMTMAT(15, ctpID);
        end
        
        function[result] = GetMarginRate(self, ctpID, code)
		   strmd = GaiaCTPMTMAT(17, ctpID, code);
           if strmd == 'E'
                result = java.util.Hashtable;
                result.put(1, 0);
                return;
            end
            titleStr = 'InstrumentID,InvestorRange,BrokerID,InvestorID,HedgeFlag,LongMarginRatioByMoney,LongMarginRatioByVolume,ShortMarginRatioByMoney,ShortMarginRatioByVolume,IsRelative';
            titArr = regexp(titleStr, ',' ,'split');
            dataArr = regexp(strmd, ',', 'split');
            retput = containers.Map();
            dataArrSize = length(dataArr);
            for i = 1:dataArrSize
                retput(char(titArr{i})) = char(dataArr{i});
            end
            result = retput;
        end
        
        function[result] = getPositionData(self, ctpID)
            strmd = GaiaCTPMTMAT(16, ctpID);
            if strmd == 'E'
                result = java.util.Hashtable;
                result.put(1, 0);
                return;
            end
            titleStr = 'InstrumentID,BrokerID,InvestorID,PosiDirection,HedgeFlag,PositionDate,YdPosition,Position,LongFrozen,ShortFrozen,LongFrozenAmount,ShortFrozenAmount,OpenVolume,CloseVolume,OpenAmount,CloseAmount,PositionCost,PreMargin,UseMargin,FrozenMargin,FrozenCash,FrozenCommission,CashIn,Commission,CloseProfit,PositionProfit,PreSettlementPrice,SettlementPrice,TradingDay,SettlementID,OpenCost,ExchangeMargin,CombPosition,CombLongFrozen,CombShortFrozen,CloseProfitByDate,CloseProfitByTrade,TodayPosition,MarginRateByMoney,MarginRateByVolume,StrikeFrozen,StrikeFrozenAmount,AbandonFrozen';
            titArr = regexp(titleStr, ',' ,'split');
            dataArr = regexp(strmd, ',', 'split');
            retput = containers.Map();
            dataArrSize = length(dataArr);
            for i = 1:dataArrSize
                retput(char(titArr{i})) = char(dataArr{i});
            end
            result = retput;
        end
        
        function[result] = getPositionDetailData(self, ctpID)
            strmd = GaiaCTPMTMAT(18, ctpID);
            if strmd == 'E' 
                result = java.util.Hashtable;
                result.put(1, 0);
                return;
            end
            titleStr = 'InstrumentID,BrokerID,InvestorID,HedgeFlag,Direction,OpenDate,TradeID,Volume,OpenPrice,TradingDay,SettlementID,TradeType,CombInstrumentID,ExchangeID,CloseProfitByDate,CloseProfitByTrade,PositionProfitByDate,PositionProfitByTrade,Margin,ExchMargin,MarginRateByMoney,MarginRateByVolume,LastSettlementPrice,SettlementPrice,CloseVolume,CloseAmount';
            titArr = regexp(titleStr, ',' ,'split');
            dataArr = regexp(strmd, ',', 'split');
            retput = containers.Map();
            dataArrSize = length(dataArr);
            for i = 1:dataArrSize
                retput(char(titArr{i})) = char(dataArr{i});
            end
            result = retput;
        end
        
        function[result] = getOrderInfo(self, ctpID)
            strmd = GaiaCTPMTMAT(19, ctpID);
            if strmd == 'E' 
                result = java.util.Hashtable;
                result.put(1, 0);
                return;
            end
            titleStr = 'BrokerID,InvestorID,InstrumentID,OrderRef,UserID,OrderPriceType,Direction,CombOffsetFlag,CombHedgeFlag,LimitPrice,VolumeTotalOriginal,TimeCondition,GTDDate,VolumeCondition,MinVolume,ContingentCondition,StopPrice,ForceCloseReason,IsAutoSuspend,BusinessUnit,RequestID,OrderLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,InstallID,OrderSubmitStatus,NotifySequence,TradingDay,SettlementID,OrderSysID,OrderSource,OrderStatus,OrderType,VolumeTraded,VolumeTotal,InsertDate,InsertTime,ActiveTime,SuspendTime,UpdateTime,CancelTime,ActiveTraderID,ClearingPartID,SequenceNo,FrontID,SessionID,LastTime,StatusMsg,UserForceClose,ActiveUserID,BrokerOrderSeq,RelativeOrderSysID,ZCETotalTradedVolume,IsSwapOrder';
            titArr = regexp(titleStr, ',' ,'split');
            dataArr = regexp(strmd, ',', 'split');
            retput = containers.Map();
            dataArrSize = length(dataArr);
            for i = 1:dataArrSize
                retput(char(titArr{i})) = char(dataArr{i});
            end
            result = retput;
        end
        
        function[result] = getOrderInfos(self, ctpID)
            GaiaCTPMTMAT(20, ctpID);
        end
        
        function[result] = getPassword(self, ctpID)
            GaiaCTPMTMAT(21, ctpID);
        end
        
        function[result] = getSessionID(self,  ctpID)
             GaiaCTPMTMAT(22, ctpID);
        end
        
        function[result] = getTradeRecord(self, ctpID)
            strmd = GaiaCTPMTMAT(23, ctpID);
            if strmd == 'E'
                result = java.util.Hashtable;
                result.put(1, 0);
                return;
            end
            titleStr = 'BrokerID,InvestorID,InstrumentID,OrderRef,UserID,ExchangeID,TradeID,Direction,OrderSysID,ParticipantID,ClientID,TradingRole,ExchangeInstID,OffsetFlag,HedgeFlag,Price,Volume,TradeDate,TradeTime,TradeType,PriceSource,TraderID,OrderLocalID,ClearingPartID,BusinessUnit,SequenceNo,TradingDay,SettlementID,BrokerOrderSeq,TradeSource';
            titArr = regexp(titleStr, ',' ,'split');
            dataArr = regexp(strmd, ',', 'split');
            retput = containers.Map();
            dataArrSize = length(dataArr);
            for i = 1:dataArrSize
                retput(char(titArr{i})) = char(dataArr{i});
            end
            result = retput;
        end
        
        function[result] = getTradeRecords(self, ctpID)
            GaiaCTPMTMAT(24, ctpID);
        end
        
        function[result] = getTradingDate(self, ctpID)
             GaiaCTPMTMAT(25, ctpID);
        end
        
        function[result] = getTradingTime(self, ctpID)
             GaiaCTPMTMAT(26, ctpID);
        end
        
        function[status] = isClearanced(self, ctpID)
            status = str2num(GaiaCTPMTMAT(27, ctpID));
        end
        
        function[logStatus] = isClearanceTime(self, ctpID)
            status = str2num(GaiaCTPMTMAT(28, ctpID));
        end
        
        function[status] = isMdLogined(self, ctpid)
            status = str2num(GaiaCTPMTMAT(29, ctpid));
        end
        
        function[status] = isTdLogined(self, ctpid)
            status = str2num(GaiaCTPMTMAT(30, ctpid));
        end
        
        function[status] = isTradingTime(self, ctpid)
            status = str2num(GaiaCTPMTMAT(31, ctpid));
        end
        
        function[status] = isTradingTimeExact(self, ctpID, code)
            status = str2num(GaiaCTPMTMAT(32,  ctpID, code));
        end 
        
        function[logStatus] = loginGaia(self, uname, upwd)
            logStatus = str2num(GaiaCTPMTMAT(33, uname, upwd));
        end
        
        function[status] = reqCommissionRate(self, ctpID, code, requestID)
            status = str2num(GaiaCTPMTMAT(34, ctpID, code, requestID));
        end 
        
        function[status] = reqInstrumentInfo(self, ctpID, requestID)
            status = str2num(GaiaCTPMTMAT(35,  ctpID, requestID));
        end 
        
        function[status] = reqQryInvestorPosition(self, ctpID, requestID)
            status = str2num(GaiaCTPMTMAT(36, ctpID, requestID));
        end
        
        function[status] = reqQryInvestorPositionDetail(self, ctpID, requestID)
            status = str2num(GaiaCTPMTMAT(37, ctpID, requestID));
        end
        
        function[status] = reqQrySettlementInfoConfirm(self, ctpID, requestID)
            status = str2num(GaiaCTPMTMAT(38, ctpID, requestID));
        end 
        
        function[status] = reqMarginRate(self,  ctpID, code, requestID)
            status = str2num(GaiaCTPMTMAT(39, ctpID, code, requestID));
        end
        
        function[status] = reqQryOrderInfo(self, ctpID, requestID)
            status = str2num(GaiaCTPMTMAT(40,  ctpID, requestID));
        end
        
        function[status] = reqQryTradingAccount(self, ctpID, requestID)
             status = str2num(GaiaCTPMTMAT(41,  ctpID, requestID));
        end
        
        function start(self, ctpid, reqid, ipmd, iptd, brokerID, uname, upwd)
            GaiaCTPMTMAT(42, ctpid, reqid, ipmd, iptd, brokerID, uname, upwd);
        end
        
        function[status] = subMarketDatas(self, ctpid, reqid, code)
            status = str2num(GaiaCTPMTMAT(43, ctpid, reqid, code));
        end
        
        function[status] = UnSubMarketDatas(self, ctpID, requestID, codes)
            status = str2num(GaiaCTPMTMAT(44, ctpID, requestID, codes));
        end  
    end
end

